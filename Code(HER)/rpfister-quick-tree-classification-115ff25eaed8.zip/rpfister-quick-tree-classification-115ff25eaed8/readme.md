Sample script to setup a quick classification tree algorithm using R

To use, download:

- R - http://cran.r-project.org/bin/windows/base/ (or whatever your operating system is)

- RStudio - http://www.rstudio.com/

Open RStudio, then within it open script.R. Click Run on the upper-right. You can also highlight specific lines and press Ctrl+R to run just that code.

If you get an error for rpart.plot, run the following command within RStudio:

  install.packages("rpart.plot")


Data column definitions and background: https://www.kaggle.com/c/titanic-gettingStarted/data
Background on Titanic route: http://www.denverpost.com/titanic/ci_20203319/map-titanic-maiden-final-voyage